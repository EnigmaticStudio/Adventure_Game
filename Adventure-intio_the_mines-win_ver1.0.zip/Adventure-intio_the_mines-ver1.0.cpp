#include <iostream>

int main() {
    char response;
    std::cout << "\nDEEP WITHIN THE EARTH LIES THE REWARD OF GRAND TREASURES, AT THE RISK OF DEFEAT FROM MONSTERS THAT LURK BENEATH THE SURFACE...";
    std::cout << "\nDO YOU DARE TO VENTURE BENEATH?";
    std::cout << "\n[Y/N]\n";
    std::cin >> response;

    while (true) {
        if (response == 'y') {
            std::cout << "\nYOUR JOURNEY BEGINS IN AN ABANDONED MINESHAFT, ONCE THE SOURCE OF ALL WEALTH IN THE REGION, HAS NOW BEEN STRIPPED OF ANYTHING OF WORTH.";
            std::cout << "\nAS YOU TRAVERSE THE MINE'S MANY PATHWAYS YOU COME ACROSS A SEEMINGLY EMPTY CART POSED AGAINST THE FAR WALL. UPON CLOSER INSPECTION, HOWEVER YOU GLIMPSE A SHINY METALLIC OBJECT FROM WITHIN";
            std::cout << "\nTHERE ARE TWO ITEMS WITHIN THE CART, HOWEVER YOU MAY CARRY ONLY ONE: ";
            std::cout << "\n[P] PICKAXE";
            std::cout << "\n[S] SWORD\n";
            std::cin >> response;

            while (response == 'p') {
                std::cout << "\nYOU HEAVE THE PICKAXE OUT OF THE CART, BEARING IT WITH BOTH ARMS, YOU VENTURE DEEPER INTO THE MINE.";
                std::cout << "\nTHIS DIMLY LIT SECTION OF THE MINE FORKS INTO THREE SEPERATE PATHS:";
                std::cout << "\n[A] A SMALL CAVE WHICH IS LITTERED WITH COBWEBS";
                std::cout << "\n[B] A DIMLY LIT SHAFT THAT CONTINUES BEYOND YOUR VISION";
                std::cout << "\n[C] A RAIL THAT FOLLOWS A SECOND SHAFT WHICH TURNS LEFT AFTER A SHORT DISTANCE\n";
                std::cin >> response;

                if (response == 'a') {
                    std::cout << "\nAS YOU ENTER THE CAVE, YOUR MOVMENT IS SLOWED BY THE THICK WEBS THAT COVER THE WALLS AND FLOOR.\nYOU HEAR A LOUD CLICKING NOISE ABOVE YOU, AS A GIGANTIC SPIDER DROPS FROM THE CEILING AND IT'S PINCERS CLEAVE YOU IN TWO";
                    std::cout << "\nTHIS IS THE END OF YOUR JOURNEY, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM";
                    return 0;
                }
                else if (response == 'b') {
                    std::cout << "\nYOU WALK DOWN THE LONG DARKENED SHAFT, EVENTUALLY COMING ACROSS A SMALL CRACK IN THE NEARBY WALL.\nYOU USE YOUR PICKAXE TO STRIKE THE CRACK, NOT LONG AFTER THE WALL CRUMBLES AWAY TO REVEAL A ALCOVE WITH A CHEST IN THE CENTRE.\nOPENING THE LID OF THE CHEST REVEALS A COLLECTION OF VARIOUS VALUABLES, YOU TAKE WHAT YOU CAN AND RETRACE YOUR STEPS OUT OF THE MINES.";
                    std::cout << "\nYOU HAVE SUCCESSFULLY COMPLETED YOUR ADVENTURE, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM";
                    return 0;
                }
                else if (response == 'c') {
                    std::cout << "\nYOU FOLLOW THE RAIL AROUND A CORNER THE PATH AHEAD IS BLOCKED BY RUBBLE.\nAS YOU APPROACH THE RUBBLE, YOU CAN SEE A SLIVER OF LIGHT THROUGH ONE OF THE GAPS BETWEEN THE ROCKS AND YOU BEGIN TO SWING YOUR PICKAXE AT THE GAP IN HOPES OF DISLODGING SOME OF THE RUBBLE.\nSHORTLY AFTER, AND EXPLOSION TRIGGERS, CRUSHING YOU WITH RUBBLE";
                    std::cout << "\nTHIS IS THE END OF YOUR JOURNEY, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM";
                    return 0;
                }
                else {
                    std::cout << "\nINVALID RESPONSE, TRY AGAIN USING A DIFFERENT KEY OR LOWERCASE LETTER\n";
                    std::cin >> response;
                }
            }
            while (response == 's') {
                std::cout << "\nYOU LIFT THE SOWRD OUT OF THE CART, GRASPING IT IN YOUR HAND, YOU VENTURE DEEPER INTO THE MINE.";
                std::cout << "\nTHIS DIMLY LIT SECTION OF THE MINE FORKS INTO THREE SEPERATE PATHS:";
                std::cout << "\n[A] A SMALL CAVE WHICH IS LITTERED WITH COBWEBS";
                std::cout << "\n[B] A DIMLY LIT SHAFT THAT CONTINUES BEYOND YOUR VISION";
                std::cout << "\n[C] A RAIL THAT FOLLOWS A SECOND SHAFT WHICH TURNS LEFT AFTER A SHORT DISTANCE\n";
                std::cin >> response;

                if (response == 'a') {
                    std::cout << "\nAS YOU ENTER THE CAVE, YOU USE YOUR SWORD TO CUT THE THICK WEBS THAT COVER THE WALLS AND FLOOR.\nYOU HEAR A LOUD CLICKING NOISE ABOVE YOU, AS A GIGANTIC SPIDER DROPS FROM THE CEILING, YOU IMPALE THE SPIDER WITH YOUR SWORD, KILLING IT.\nSCAVENGING AROUND, YOU COME ACROSS A CHEST, COVERED IN COBWEBS.\nOPENING THE LID OF THE CHEST REVEALS A COLLECTION OF VARIOUS VALUABLES, YOU TAKE WHAT YOU CAN AND RETRACE YOUR STEPS OUT OF THE MINES.";
                    std::cout << "\nYOU HAVE SUCCESSFULLY COMPLETED YOUR ADVENTURE, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM";
                    return 0;
                }
                else if (response == 'b') {
                    std::cout << "\nYOU WALK DOWN THE LONG DARKENED SHAFT UNTIL IT BECOMES TOO DARK TO SEE ANYTHING.\nAS YOU TAKE YOUR NEXT STEP, YOU FALL DOWN AND YOUR BODY HITS THE FLOOR, LIFELESS";
                    std::cout << "\nTHIS IS THE END OF YOUR JOURNEY, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM";
                    return 0;
                }
                else if (response == 'c') {
                    std::cout << "\nYOU FOLLOW THE RAIL AROUND A CORNER THE PATH AHEAD IS BLOCKED BY RUBBLE.\nAS YOU APPROACH THE RUBBLE, YOU CAN SEE A SLIVER OF LIGHT THROUGH ONE OF THE GAPS BETWEEN THE ROCKS, YOU WEDGE YOUR SWORD IN THE GAP AND PRESS AGAINST IT IN HOPES OF DISLODGING SOME OF THE RUBBLE.\nSHORTLY AFTER, AND EXPLOSION TRIGGERS, CRUSHING YOU WITH RUBBLE";
                    std::cout << "\nTHIS IS THE END OF YOUR JOURNEY, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM";
                    return 0;
                }
                else {
                    std::cout << "\nINVALID RESPONSE, TRY AGAIN USING A DIFFERENT KEY OR LOWERCASE LETTER\n";
                    std::cin >> response;
                }
            }

        }
        else if (response == 'n') {
            std::cout << "\nONE DAY YOU SHALL HAVE THE COURAGE TO VENTURE INTO THE DEPTHS...";
            return 0;
        }
        else {
            std::cout << "\nINVALID RESPONSE, TRY AGAIN USING A DIFFERENT KEY OR LOWERCASE LETTER\n";
            std::cin >> response;
        }
    } return 0;
}