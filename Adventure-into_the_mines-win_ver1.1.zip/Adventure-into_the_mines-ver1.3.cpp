//includes the 'iostream' library which provides basic input and output for use later in the code.
#include <iostream>
//includes the 'chrono' library which provides functions using time, it is used in this code to provide dedlays between keypresses
#include <chrono>
//includes the 'thread' library which allows the use of threads, which allow intructions to be run at the same time.
#include <thread>
//begin the 'main' function, startring the program.
int main() {
    //the 'response' variable only accepts single characters, because the program uses this variable each time it needs an input, it can only recieve values that are a single character long.
    char response;
    //the next three lines of code prints the sting inside the "", and the '<<std::endl;' part creates a new line for the next part of the string to go on.
    std::cout << "DEEP WITHIN THE EARTH LIES THE REWARD OF GRAND TREASURES, AT THE RISK OF DEFEAT FROM MONSTERS THAT LURK BENEATH THE SURFACE..." << std::endl;
    std::cout << "DO YOU DARE TO VENTURE BENEATH?" << std::endl;
    //the '\n' part of the next line essentially has the same function as '<< std::cout endl'
    std::cout << "[Y/N]" << std::endl;
    //taking a typed input from the user, and setting it to the value of the 'response' variable.
    std::cin >> response;
    //this is a 'while' loop, which starts at the '{'continues intil it is finished by the '}'.
    while (true) {
        //if the response variable is equal to 'y' then print the following lines.
        if (response == 'y') {
            std::cout << "YOUR JOURNEY BEGINS IN AN ABANDONED MINESHAFT, ONCE THE SOURCE OF ALL WEALTH IN THE REGION, HAS NOW BEEN STRIPPED OF ANYTHING OF WORTH." << std::endl;
            std::cout << "AS YOU TRAVERSE THE MINE'S MANY PATHWAYS YOU COME ACROSS A SEEMINGLY EMPTY CART POSED AGAINST THE FAR WALL. UPON CLOSER INSPECTION, HOWEVER YOU GLIMPSE A SHINY METALLIC OBJECT FROM WITHIN" << std::endl;
            std::cout << "THERE ARE TWO ITEMS WITHIN THE CART, HOWEVER YOU MAY CARRY ONLY ONE: " << std::endl;
            std::cout << "[P] PICKAXE" << std::endl;
            std::cout << "[S] SWORD" << std::endl;
            std::cin >> response;
            // while the response from the previous input equals 'p'.
                while (response == 'p') {
                    std::cout << "YOU HEAVE THE PICKAXE OUT OF THE CART, BEARING IT WITH BOTH ARMS, YOU VENTURE DEEPER INTO THE MINE." << std::endl;
                    std::cout << "THIS DIMLY LIT SECTION OF THE MINE FORKS INTO THREE SEPERATE PATHS:" << std::endl;
                    std::cout << "[A] A SMALL CAVE WHICH IS LITTERED WITH COBWEBS" << std::endl;
                    std::cout << "[B] A DIMLY LIT SHAFT THAT CONTINUES BEYOND YOUR VISION" << std::endl;
                    std::cout << "[C] A RAIL THAT FOLLOWS A SECOND SHAFT WHICH TURNS LEFT AFTER A SHORT DISTANCE" << std::endl;
                    std::cin >> response;
                    
                    if (response == 'a') {
                        std::cout << "AS YOU ENTER THE CAVE, YOUR MOVMENT IS SLOWED BY THE THICK WEBS THAT COVER THE WALLS AND FLOOR." << std::endl;
                        std::cout << "YOU HEAR A LOUD CLICKING NOISE ABOVE YOU, AS A GIGANTIC SPIDER DROPS FROM THE CEILING AND IT'S PINCERS CLEAVE YOU IN TWO" << std::endl;
                        std::cout << "THIS IS THE END OF YOUR JOURNEY, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM" << std::endl;
                        std::cout << "(THE PROGRAM WILL CLOSE AUTOMATICALLY)" << std::endl;
                        //this line adds a delay to the program for a specified ammount of time, in this case it's 10 seconda. 
                        std::this_thread::sleep_for(std::chrono::seconds(10));
                        //return  0; tells the program that is has been sucessfully completed.
                        return 0;
                        //in the case that the 'response' variable does not equal 'a', the else statement gives another value option.
                    } else if (response == 'b') {
                        std::cout << "YOU WALK DOWN THE LONG DARKENED SHAFT, EVENTUALLY COMING ACROSS A SMALL CRACK IN THE NEARBY WALL." << std::endl;
                        std::cout << "YOU USE YOUR PICKAXE TO STRIKE THE CRACK, NOT LONG AFTER THE WALL CRUMBLES AWAY TO REVEAL A ALCOVE WITH A CHEST IN THE CENTRE." << std::endl;
                        std::cout << "OPENING THE LID OF THE CHEST REVEALS A COLLECTION OF VARIOUS VALUABLES, YOU TAKE WHAT YOU CAN AND RETRACE YOUR STEPS OUT OF THE MINES." << std::endl;
                        std::cout << "YOU HAVE SUCCESSFULLY COMPLETED YOUR ADVENTURE, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM" << std::endl;
                        std::cout << "(THE PROGRAM WILL CLOSE AUTOMATICALLY)" << std::endl;
                        std::this_thread::sleep_for(std::chrono::seconds(10));
                        return 0;
                    } else if (response == 'c') {
                        std::cout << "YOU FOLLOW THE RAIL AROUND A CORNER THE PATH AHEAD IS BLOCKED BY RUBBLE." << std::endl;
                        std::cout << "AS YOU APPROACH THE RUBBLE, YOU CAN SEE A SLIVER OF LIGHT THROUGH ONE OF THE GAPS BETWEEN THE ROCKS AND YOU BEGIN TO SWING YOUR PICKAXE AT THE GAP, IN HOPES OF DISLODGING SOME OF THE RUBBLE." << std::endl;
                        std::cout << "SHORTLY AFTER, AND EXPLOSION TRIGGERS, CRUSHING YOU WITH RUBBLE" << std::endl;
                        std::cout << "THIS IS THE END OF YOUR JOURNEY, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM\n";
                        std::cout << "(THE PROGRAM WILL CLOSE AUTOMATICALLY)" << std::endl;
                        std::this_thread::sleep_for(std::chrono::seconds(10));
                        return 0;
                    } else {
                        std::cout << "INVALID RESPONSE, TRY AGAIN USING A DIFFERENT KEY OR LOWERCASE LETTER" << std::endl;
                        std::cin >> response;
                    }  
                }
                while (response == 's') { 
                    std::cout << "YOU LIFT THE SOWRD OUT OF THE CART, GRASPING IT IN YOUR HAND, YOU VENTURE DEEPER INTO THE MINE." << std::endl;
                    std::cout << "THIS DIMLY LIT SECTION OF THE MINE FORKS INTO THREE SEPERATE PATHS:" << std::endl;
                    std::cout << "[A] A SMALL CAVE WHICH IS LITTERED WITH COBWEBS" << std::endl;
                    std::cout << "[B] A DIMLY LIT SHAFT THAT CONTINUES BEYOND YOUR VISION" << std::endl;
                    std::cout << "[C] A RAIL THAT FOLLOWS A SECOND SHAFT WHICH TURNS LEFT AFTER A SHORT DISTANCE" << std::endl;
                    std::cin >> response;

                    if (response == 'a') {
                        std::cout << "AS YOU ENTER THE CAVE, YOU USE YOUR SWORD TO CUT THE THICK WEBS THAT COVER THE WALLS AND FLOOR." << std::endl;
                        std::cout << "YOU HEAR A LOUD CLICKING NOISE ABOVE YOU, AS A GIGANTIC SPIDER DROPS FROM THE CEILING, YOU IMPALE THE SPIDER WITH YOUR SWORD, KILLING IT." << std::endl;
                        std::cout << "SCAVENGING AROUND, YOU COME ACROSS A CHEST, COVERED IN COBWEBS." << std::endl;
                        std::cout << "OPENING THE LID OF THE CHEST REVEALS A COLLECTION OF VARIOUS VALUABLES, YOU TAKE WHAT YOU CAN AND RETRACE YOUR STEPS OUT OF THE MINES." << std::endl;
                        std::cout << "YOU HAVE SUCCESSFULLY COMPLETED YOUR ADVENTURE, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM" << std::endl;
                        std::cout << "(THE PROGRAM WILL CLOSE AUTOMATICALLY)" << std::endl;
                        std::this_thread::sleep_for(std::chrono::seconds(10));
                        return 0;
                    } else if (response == 'b') {
                        std::cout << "YOU WALK DOWN THE LONG DARKENED SHAFT UNTIL IT BECOMES TOO DARK TO SEE ANYTHING." << std::endl;
                        std::cout << "AS YOU TAKE YOUR NEXT STEP, YOU FALL DOWN AND YOUR BODY HITS THE FLOOR, LIFELESS" << std::endl;
                        std::cout << "THIS IS THE END OF YOUR JOURNEY, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM" << std::endl;
                        std::cout << "(THE PROGRAM WILL CLOSE AUTOMATICALLY)" << std::endl;
                        std::this_thread::sleep_for(std::chrono::seconds(10));
                        return 0;
                    } else if (response == 'c') {
                        std::cout << "YOU FOLLOW THE RAIL AROUND A CORNER THE PATH AHEAD IS BLOCKED BY RUBBLE." << std::endl;
                        std::cout << "AS YOU APPROACH THE RUBBLE, YOU CAN SEE A SLIVER OF LIGHT THROUGH ONE OF THE GAPS BETWEEN THE ROCKS, YOU WEDGE YOUR SWORD IN THE GAP AND PRESS AGAINST IT IN HOPES OF DISLODGING SOME OF THE RUBBLE." << std::endl; 
                        std::cout << "SHORTLY AFTER, AND EXPLOSION TRIGGERS, CRUSHING YOU WITH RUBBLE" << std::endl;
                        std::cout << "THIS IS THE END OF YOUR JOURNEY, IF YOU WISH TO TRY AGAIN, RESTART THE PROGRAM" << std::endl;
                        std::cout << "(THE PROGRAM WILL CLOSE AUTOMATICALLY)" << std::endl;
                        std::this_thread::sleep_for(std::chrono::seconds(10));
                        return 0;
                    } else {
                    std::cout << "INVALID RESPONSE, TRY AGAIN USING A DIFFERENT KEY OR LOWERCASE LETTER" << std::endl;
                    std::cin >> response;
                    }
                }
                
            } else if (response == 'n') {
            std::cout << "\nONE DAY YOU SHALL HAVE THE COURAGE TO VENTURE INTO THE DEPTHS..." << std::endl;
            std::cout << "(THE PROGRAM WILL CLOSE AUTOMATICALLY)" << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(10));
            return 0;
        } else {
            std::cout << "INVALID RESPONSE, TRY AGAIN USING A DIFFERENT KEY OR LOWERCASE LETTER" << std::endl;
            std::cin >> response;
        }
      std::cout << "(THE PROGRAM WILL CLOSE AUTOMATICALLY)" << std::endl;
      std::this_thread::sleep_for(std::chrono::seconds(10));
    } return 0;
} 